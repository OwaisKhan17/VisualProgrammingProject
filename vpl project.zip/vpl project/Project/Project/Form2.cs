﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MaterialSkin.Controls;
using MaterialSkin.Animations;
using MaterialSkin;
using System.Configuration;
using System.Data.SqlClient;

namespace Project
{
    public partial class Form2 : MaterialForm
    {
        SqlConnection con;
        SqlCommand cmd;
        SqlDataAdapter adap;
        public static string conStr;
        public static string Student_Name;
        public static string FatherName;
        public static string Courses;
        public static Int32 Contact_No;
        public static string Student_Email;

        public Form2()
        {
            conStr = ConfigurationManager.ConnectionStrings["dbx"].ConnectionString;
            con = new SqlConnection(conStr);

            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void materialLabel2_Click(object sender, EventArgs e)
        {

        }

        private void materialLabel3_Click(object sender, EventArgs e)
        {

        }

        private void materialLabel5_Click(object sender, EventArgs e)
        {

        }

        private void materialLabel4_Click(object sender, EventArgs e)
        {

        }

        private void materialLabel6_Click(object sender, EventArgs e)
        {

        }

        private void materialLabel1_Click(object sender, EventArgs e)
        {

        }

        private void materialRaisedButton5_Click(object sender, EventArgs e)
        {
            adap = new SqlDataAdapter("select * from Student_Detail ", con);
            DataTable dt = new DataTable();
            adap.Fill(dt);
            dataGridView1.Rows.Clear();
            foreach (DataRow dr in dt.Rows)
            {
                int n = dataGridView1.Rows.Add();
                dataGridView1.Rows[n].Cells[0].Value = dr[0].ToString();
                dataGridView1.Rows[n].Cells[1].Value = dr[1].ToString();
                dataGridView1.Rows[n].Cells[2].Value = dr[2].ToString();
                dataGridView1.Rows[n].Cells[3].Value = dr[3].ToString();
                dataGridView1.Rows[n].Cells[4].Value = dr[4].ToString();
                dataGridView1.Rows[n].Cells[5].Value = dr[5].ToString();
            }
        }

        private void materialRaisedButton1_Click(object sender, EventArgs e)
        {

            if (id.Text == "" || name.Text == "" || fname.Text == "" || courses.SelectedItem.ToString() == "" || contact.Text == "" || email.Text == "")
            {
                MessageBox.Show("Please Fill All Fields", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            else
            {
                con.Open();
                string query = "insert into Student_Detail values('" + this.id.Text + "','" + this.name.Text + "','" + this.fname.Text + "','" + this.courses.SelectedItem.ToString() + "','" + this.contact.Text + "','" + this.email.Text + "')";
                cmd = new SqlCommand(query, con);
                SqlDataAdapter adap = new SqlDataAdapter(cmd);
                cmd.ExecuteNonQuery();
                con.Close();
                clear();
                show();
                MessageBox.Show("New Record Inserted Successfully.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
        }
        void clear()
        {

            id.Text = "";
            name.Text = "";
            fname.Text = "";
            courses.Text = "";
            contact.Text = "";
            email.Text = "";

        }

        void show()
        {
            SqlDataAdapter adap = new SqlDataAdapter("select * from Student_Detail", con);
            DataTable dt = new DataTable();
            adap.Fill(dt);
            dataGridView1.Rows.Clear();
            foreach (DataRow dr in dt.Rows)
            {
                int n = dataGridView1.Rows.Add();
                dataGridView1.Rows[n].Cells[0].Value = dr[0].ToString();
                dataGridView1.Rows[n].Cells[1].Value = dr[1].ToString();
                dataGridView1.Rows[n].Cells[2].Value = dr[2].ToString();
                dataGridView1.Rows[n].Cells[3].Value = dr[3].ToString();
                dataGridView1.Rows[n].Cells[4].Value = dr[4].ToString();
                dataGridView1.Rows[n].Cells[5].Value = dr[5].ToString();
            }
        }

        private void id_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if (!Char.IsDigit(ch) && ch!=8 )
            {
                e.Handled = true;
            }
        }

        private void contact_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if (!Char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;
            }
        }

        private void materialRaisedButton3_Click(object sender, EventArgs e)
        {
            con.Open();
            string query = "DELETE  from Student_Detail where Student_ID='" + id.Text + "'";
            cmd = new SqlCommand(query, con);
            SqlDataAdapter adap = new SqlDataAdapter(cmd);
            cmd.ExecuteNonQuery();
            con.Close();
            clear();
            show();
            MessageBox.Show("Selected Record Deleted Successfully.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);

        }

        private void materialRaisedButton2_Click(object sender, EventArgs e)
        {



            con.Open();

            string query = "update Student_Detail set Student_ID='" + id.Text + "',Student_Name='" + name.Text + "',FatherName ='" + fname.Text + "',Courses='" + courses.SelectedItem.ToString() + "',Contact_No='" + contact.Text + "',Student_Email='" + email.Text + "' where Student_ID='" + id.Text + "'";
            cmd = new SqlCommand(query, con);
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Record Updated Successfully.", "Successful", MessageBoxButtons.OK, MessageBoxIcon.Information);
            clear();

            show();

        }

        private void dataGridView1_MouseClick(object sender, MouseEventArgs e)
        {
            id.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            name.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            fname.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
            courses.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
            contact.Text = dataGridView1.SelectedRows[0].Cells[4].Value.ToString();
            email.Text = dataGridView1.SelectedRows[0].Cells[5].Value.ToString();

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            id.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            name.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            fname.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
            courses.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
            contact.Text = dataGridView1.SelectedRows[0].Cells[4].Value.ToString();
            email.Text = dataGridView1.SelectedRows[0].Cells[5].Value.ToString();
        }
    }
}
